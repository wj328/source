##任务分配  

1.git 建立

2.Redis 业务分析

3.C++ 编程规范 / 架构，C/S ，doc ,PDF ,PPt .PICTURE.....

4.基本结构图

