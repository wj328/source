/*************************************************************************
	> File Name: FDB_IO.h
	> Author: 
	> Mail: 
	> Created Time: 2016年04月20日 星期三 12时25分34秒
 ************************************************************************/

#ifndef _FDB_IO_H
#define _FDB_IO_H

#include<iostream>
#include<unistd.h>


int Write();


int Rread();


int Open();


int Close(int fd);




#endif
