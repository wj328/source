/*************************************************************************
	> File Name: FDB_Data_num.h
	> Author: wrx
	> Mail: 1721267632@qq.com
	> Created Time: 2016年04月26日 星期二 22时00分23秒
 ************************************************************************/

#ifndef _FDB_DATA_NUM_H
#define _FDB_DATA_NUM_H

#define Hash_Map_pseudo_NUM 0
#define Hash_Map_NUM 1
#define Ziplist_NUM 2
#define String_NUM 3
#define Stack_NUM 4
#define Queue_NUM 5

#endif
