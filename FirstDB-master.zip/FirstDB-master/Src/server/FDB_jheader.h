/*************************************************************************
	> File Name: FDB_header.h
	> Author:Eval 
	> Mail:1040460587@qq.com 
	> Created Time: 2016年07月26日 星期二 14时27分26秒
 ************************************************************************/

#ifndef _FDB_HEADER_H
#define _FDB_HEADER_H

//#define PORT 9201
#define MAXLINE 4096

#include"../jsoncpp-src-0.5.0/include/json/json.h"

#endif

