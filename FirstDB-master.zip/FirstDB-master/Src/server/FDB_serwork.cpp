/*************************************************************************
	> File Name: FDB_serwork.cpp
	> Author: 
	> Mail: 
	> Created Time: 2016年05月04日 星期三 17时07分40秒
 ************************************************************************/

#include<iostream>
#include"./FDB_serwork.h"

using namespace std;


/*Server_work::Server_work(int connfd){

    
    connfd_sockfd = connfd;

}


int Server_work::do_work(){






}


int Server_work::Server_read(){




    
}


int Server_work::Server_translation



int Server_work::Server_dowork(){
    
    
    
    

}*/




