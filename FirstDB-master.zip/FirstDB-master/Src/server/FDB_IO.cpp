/*************************************************************************
	> File Name: FDB_IO.cpp
	> Author: 
	> Mail: 
	> Created Time: 2016年04月20日 星期三 12时25分39秒
 ************************************************************************/

#include<iostream>
#include"./FDB_IO.h"



int Close(int fd){


    close(fd);

}
