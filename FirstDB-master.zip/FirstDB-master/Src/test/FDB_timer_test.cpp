/*************************************************************************
	> File Name: FDB_timer_test.cpp
	> Author: 
	> Mail: 
	> Created Time: 2016年04月20日 星期三 11时20分19秒
 ************************************************************************/

#include<iostream>
#include"./FDB_timer.h"
#include"./FDB_timer.cpp"


using namespace std;


int main(){

    timer test;
    test.timer_loop(3,100,0,true);
    



}

