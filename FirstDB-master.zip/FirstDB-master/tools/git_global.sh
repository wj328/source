#!/bin/bash


git config --global  user.email$1

git config --global  user.name$2


