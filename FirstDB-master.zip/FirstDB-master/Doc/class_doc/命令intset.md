
**整数集合命令**

my_insert(s) :  向整数集合添加元素s  INTSETADD

intset_delete(s)：从整数集合删除元素s  INTSETDEL

print_int()：输出整数集合  INTSETPRINT

get_size(): 返回集合中元素的个数 INTSETSIZE

get_bit_size():返回集合占用的总字节数 INTSETBIT

my_less_sort():给集合按升序排序  INTSETLESS

my_greater_sort()：给集合按降序排序 INTSETGREATER

find_intset(): 从集合中查找元素s INTSETFIND
