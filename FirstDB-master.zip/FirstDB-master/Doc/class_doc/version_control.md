使用github进行版本控制。

github：
	
	zmr961006

	scentsoul
	
	wrx1721267632



同步：
	
	1.compare

	2.base fork->次分支git       		head fork ->主分支git
	
	3.Create pull request，

	4.Merge pull
	
	5.命令行下git pull origin master


提交：
	
	1.git push origin master（上传内容）
	
	2.pull request。
    
	3.Create pull request.
	
	4.确认

注意： 	每次提交前需要先对主分支进行同步。
